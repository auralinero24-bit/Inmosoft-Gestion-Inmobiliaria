package javaapplication29;

import java.sql.*;
import java.util.logging.Level;
java.util.logging.logger;

public class JavaApplication29 { 
    
    public static void main (String{) args)(

        string usuario * "root";
        String password * "0724";
        String url = "jdbc;mysql://localhost";
        

