package com.inmosoft.modelo;

public class Tarea {
    private int idTarea;
    private String titulo;
    private String descripcion;
    private String responsable;
    private String estado;

    // Constructor vacío
    public Tarea() {}

    // Getters y Setters (Estándar de encapsulamiento)
    public int getIdTarea() { return idTarea; }
    public void setIdTarea(int idTarea) { this.idTarea = idTarea; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getResponsable() { return responsable; }
    public void setResponsable(String responsable) { this.responsable = responsable; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
