package com.inmosoft.dao;

import com.inmosoft.conexion.Conexion;
import com.inmosoft.modelo.Tarea;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TareaDAO {

    // MÉTODO PARA INSERTAR (CREAR)
    public boolean insertar(Tarea tarea) {
        String sql = "INSERT INTO tareas (titulo, descripcion, responsable) VALUES (?, ?, ?)";
        
        try (Connection con = Conexion.conectar(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, tarea.getTitulo());
            ps.setString(2, tarea.getDescripcion());
            ps.setString(3, tarea.getResponsable());
            
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar tarea: " + e.getMessage());
            return false;
        }
    }

    // MÉTODO PARA CONSULTAR (LEER TODO)
    public List<Tarea> consultarTodas() {
        List<Tarea> lista = new ArrayList<>();
        String sql = "SELECT * FROM tareas";
        
        try (Connection con = conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Tarea t = new Tarea();
                t.setIdTarea(rs.getInt("id_tarea"));
                t.setTitulo(rs.getString("titulo"));
                t.setDescripcion(rs.getString("descripcion"));
                t.setResponsable(rs.getString("responsable"));
                t.setEstado(rs.getString("estado"));
                lista.add(t);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }
        return lista;
    }
}

