package com.inmosoft.main;

import com.inmosoft.dao.TareaDAO;
import com.inmosoft.modelo.Tarea;
import java.util.List;

public class Principal {

    public static void main(String[] args) {
        // 1. Creamos el objeto DAO y una tarea de prueba
        TareaDAO dao = TareaDAO.conectar(); // Cambiamos esto si es necesario
        Tarea nuevaTarea = new Tarea();
        
        // Llenamos los datos de la tarea siguiendo los estándares
        nuevaTarea.setTitulo("Revisión Apartamento 101");
        nuevaTarea.setDescripcion("Verificar estado de la pintura y grifería");
        nuevaTarea.setResponsable("Aura Karina");

        // 2. Intentamos insertar en la base de datos
        System.out.println("--- Iniciando prueba de Inmosoft ---");
        TareaDAO tareaDao = new TareaDAO();
        
        if (tareaDao.insertar(nuevaTarea)) {
            System.out.println("¡ÉXITO! Tarea guardada en la base de datos.");
        } else {
            System.out.println("ERROR: No se pudo guardar la tarea.");
        }

        // 3. Consultamos para ver si aparece en la lista
        System.out.println("\n--- Listado de Tareas Actuales ---");
        List<Tarea> lista = tareaDao.consultarTodas();
        for (Tarea t : lista) {
            System.out.println("ID: " + t.getIdTarea() + " | Título: " + t.getTitulo() + " | Responsable: " + t.getResponsable());
        }
    }
}
